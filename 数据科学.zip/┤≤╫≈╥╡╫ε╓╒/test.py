import json
import random
import matplotlib.pyplot as plt

def isjson(myjson):
    """判断是否为json对象"""
    try:
        json_object = json.loads(myjson)
    except Exception as e:
        return False
    return True

def get_target_value(key, dic, tmp_list):
    """
    :param key: 目标key值
    :param dic: JSON数据
    :param tmp_list: 用于存储获取的数据
    :return: list
    """
    if not isinstance(dic, dict) or not isinstance(tmp_list, list):  # 对传入数据进行格式校验
        return 'argv[1] not an dict or argv[-1] not an list '

    if key in dic.keys():
        tmp_list.append(dic[key])  # 传入数据存在则存入tmp_list
    else:
        for value in dic.values():  # 传入数据不符合则对其value值进行遍历
            if isinstance(value, dict):
                get_target_value(key, value, tmp_list)  # 传入数据的value值是字典，则直接调用自身
            elif isinstance(value, (list, tuple)):
                _get_value(key, value, tmp_list)  # 传入数据的value值是列表或者元组，则调用_get_value
            elif isjson(value):
                value1 = json.loads(value)
                get_target_value(key, value1, tmp_list)  #传入数据的value值是json字符串，则装载成python对象，并调用自身
    return tmp_list


def _get_value(key, val, tmp_list):
    for val_ in val:
        if isinstance(val_, dict):
            get_target_value(key, val_, tmp_list)  # 传入数据的value值是字典，则调用get_target_value
        elif isinstance(val_, (list, tuple)):
            _get_value(key, val_, tmp_list)   # 传入数据的value值是列表或者元组，则调用自身
        elif isjson(val_):
            value2 = json.loads(val_)
            get_target_value(key, value2, tmp_list)   #传入数据的value值是json字符串，则装载成python对象，并调用get_target_value

f=open('test_data.json',encoding='utf-8')
res=f.read()
data=json.loads(res)
print(len(data))
list1=[]
list1=get_target_value('score',data,list1)

finallsit=[]
recordsumlist=[]



keys=list(data.keys())
for i in range(10):
    j=keys[random.randint(0,len(keys)-1)]
    cases=data[j]["cases"]
    print(j)
    recordsnum=0
    finalscore=0
    scorelist=[]
    for i in range(0,len(cases)):
        recordsnum=len(cases[i]['upload_records'])+recordsnum
        finalscore=finalscore+cases[i]['final_score']
        scorelist.append(cases[i]['final_score'])
    print(recordsnum)
    print(finalscore)
    finallsit.append(finalscore)
    recordsumlist.append(recordsnum)
    i=0


plt.plot(recordsumlist, finallsit, 'ro-', color='#4169E1', alpha=0.8, linewidth=1, label='一些数字')
plt.legend(loc="upper right")
plt.xlabel('x轴数字')
plt.ylabel('y轴数字')
plt.show()